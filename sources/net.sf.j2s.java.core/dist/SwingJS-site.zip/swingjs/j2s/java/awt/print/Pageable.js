(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Pageable");

C$.$fields$=[[]
,['I',['UNKNOWN_NUMBER_OF_PAGES']]]

C$.$static$=function(){C$.$static$=0;
C$.UNKNOWN_NUMBER_OF_PAGES=-1;
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-27 15:34:58 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
