(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Printable");

C$.$fields$=[[]
,['I',['PAGE_EXISTS','NO_SUCH_PAGE']]]

C$.$static$=function(){C$.$static$=0;
C$.PAGE_EXISTS=0;
C$.NO_SUCH_PAGE=1;
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-27 15:34:58 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
