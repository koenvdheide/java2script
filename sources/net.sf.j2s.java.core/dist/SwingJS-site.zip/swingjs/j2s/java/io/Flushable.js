(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Flushable");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-27 15:35:02 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
